$ErrorActionPreference = 'Stop'

$workspace = (Get-Location).Path
$userProfile = $env:USERPROFILE
$zipPath = Join-Path (Join-Path $userProfile 'Downloads') 'Naama_CR_Merger_Project_With_Conversation.zip'
$brainSrc = Join-Path (Join-Path (Join-Path $userProfile '.gemini') 'antigravity') 'brain\c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9'

$tempDir = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), 'NaamaExport')
if (Test-Path $tempDir) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force
}

$projDir = Join-Path $tempDir 'Project_Files'
$brainDest = Join-Path $tempDir 'Conversation_Brain\c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9'

New-Item -ItemType Directory -Path $projDir -Force | Out-Null
New-Item -ItemType Directory -Path $brainDest -Force | Out-Null

# Copy Workspace files
Get-ChildItem -LiteralPath $workspace -File | Where-Object { $_.Extension -ne '.zip' } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $projDir -Force
}

# Copy Brain folder including all hidden dotfiles (.system_generated, .user_uploaded, etc.)
Get-ChildItem -LiteralPath $brainSrc -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $brainDest -Recurse -Force
}

# Add Instructions file in Arabic
$readmeText = @"
# دليل استئناف المحادثة والمشروع على جهاز آخر

مرحباً بك! يحتوي هذا الملف المضغوط على كل ما يلزمك لمتابعة العمل واستئناف هذه المحادثة بالكامل على أي جهاز كمبيوتر آخر.

---

## محتويات الحزمة:
1. **مجلد ملفات المشروع (Project_Files)**:
   - index.html: صفحة الغلاف والمدخل الرئيسي المتوافقة مع GitHub Pages.
   - interactive_analysis_document.html: وثيقة التحليل الفني والنظامي التفاعلية.
   - naama_complete_solution.html: النموذج المبدئي التفاعلي الشامل لرحلة الخدمة.
   - naama_transfer_workflow.html: محاكاة تدفق نقل وتصحيح التراخيص.
   - naama_service_design.html: تصميم كرت الخدمة في دليل الخدمات.
   - commercial_register_merger_analysis.md: وثيقة التحليل الفني باللغة العربية.
   - naama_logo.png: شعار منصة نما المعتمد.

2. **مجلد سياق المحادثة (Conversation_Brain)**:
   - يحتوي على المجلد: c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9
   - يشمل كافة سجلات التفاعل والنصوص والصور المرفوعة وسياق الذكاء الاصطناعي كاملاً.

---

## كيف تستأنف المحادثة على جهازك الجديد في Antigravity؟
1. في جهازك الآخر، انتقل إلى المسار:
   - في نظام ويندوز (Windows):
     C:\Users\<اسم_المستخدم>\.gemini\antigravity\brain\
   - في نظام ماك أو لينكس (macOS / Linux):
     ~/.gemini/antigravity/brain/
2. انسخ المجلد c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9 بالكامل وضعه داخل مجلد brain المذكور أعلاه.
3. افتح مجلد Project_Files كمساحة عمل (Workspace) في محرر Antigravity.
4. ستظهر المحادثة فوراً في التطبيق بكامل سجلها وتفاصيلها وسياقها ويمكنك إكمال النقاش والبرمجة مباشرة كأنك على جهازك الحالي!

---
تاريخ التصدير: 26 أكتوبر 2026
منصة نما - وزارة البيئة والمياه والزراعة
"@

[System.IO.File]::WriteAllText((Join-Path $tempDir 'تعليمات_استئناف_المحادثة_على_جهاز_آخر.txt'), $readmeText, [System.Text.Encoding]::UTF8)

if (Test-Path $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}

Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath -CompressionLevel Optimal
Copy-Item -LiteralPath $zipPath -Destination $workspace -Force
Remove-Item -LiteralPath $tempDir -Recurse -Force

Write-Host "ZIP_CREATED_SUCCESSFULLY"
Get-Item -LiteralPath $zipPath | Select-Object FullName, Length
