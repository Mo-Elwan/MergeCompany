$ErrorActionPreference = 'Stop'

$staging = Join-Path $env:TEMP 'naama_export_bundle'
if (Test-Path $staging) {
    Remove-Item -Path $staging -Recurse -Force
}

$dir1 = Join-Path $staging "1-ملفات_المشروع_والنماذج"
$dir2 = Join-Path $staging "2-بيانات_المحادثة_الذكية_Brain\c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9"

New-Item -ItemType Directory -Path $dir1 -Force | Out-Null
New-Item -ItemType Directory -Path $dir2 -Force | Out-Null

# Copy Project Workspace Files
$workspace = "c:\Users\Mohamed Elwan\Downloads\دمج السجلات التجارية"
Get-ChildItem -Path $workspace -File | Where-Object { $_.Extension -ne '.zip' } | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $dir1 -Force
}

# Copy Brain folder
$brainSrc = "C:\Users\Mohamed Elwan\.gemini\antigravity\brain\c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9"
Copy-Item -Path "$brainSrc\*" -Destination $dir2 -Recurse -Force

# Readme content
$lines = @(
    "# دليل استئناف العمل ونقل المحادثة إلى جهاز آخر",
    "",
    "مرحباً بك! يحتوي هذا الأرشيف على كافة ملفات ونماذج المشروع بالإضافة إلى سياق وبيانات المحادثة كاملة للعمل عليها من أي جهاز آخر.",
    "",
    "---",
    "",
    "## محتويات الحزمة:",
    "1. **1-ملفات_المشروع_والنماذج**:",
    "   - `index.html`: صفحة الغلاف الرسمية الجاهزة لـ GitHub Pages.",
    "   - `interactive_analysis_document.html`: وثيقة التحليل الفني والنظامي التفاعلية.",
    "   - `naama_complete_solution.html`: النموذج المبدئي التفاعلي الشامل لرحلة الخدمة.",
    "   - `naama_transfer_workflow.html`: محاكاة نقل التراخيص والطلبات.",
    "   - `naama_service_design.html`: كرت وتصميم الخدمة في الدليل.",
    "   - `commercial_register_merger_analysis.md`: التقرير الفني الشامل بصيغة ماركداون.",
    "   - `naama_logo.png`: شعار منصة نما المعتمد.",
    "",
    "2. **2-بيانات_المحادثة_الذكية_Brain**:",
    "   - يحتوي على مجلد المحادثة: `c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9`",
    "   - يشمل كافة سجلات التفاعل (Transcripts)، وتاريخ القرارات والملفات المرفوعة.",
    "",
    "---",
    "",
    "## خطوات استئناف المحادثة في بيئة Antigravity على جهازك الآخر:",
    "1. على جهازك الجديد، افتح المجلد:",
    "   - في ويندوز: C:\Users\<Username>\.gemini\antigravity\brain\",
    "   - في ماك / لينكس: ~/.gemini/antigravity/brain/",
    "2. انسخ مجلد المحادثة c45bedc3-6ae4-48eb-a1a7-d61d4b5382a9 وضعه داخل مسار brain.",
    "3. انسخ محتويات مجلد 1-ملفات_المشروع_والنماذج إلى أي مجلد تريده وافتحه كـ Workspace.",
    "4. عند فتح تطبيق Antigravity ستتعرف الأداة تلقائياً على المحادثة السابقة بكامل تفاصيلها وسياقها ويمكنك إكمال العمل من النقطة التي توقفت عندها مباشرة.",
    "",
    "---",
    "تاريخ التصدير: 26 أكتوبر 2026",
    "منظومة نما - وزارة البيئة والمياه والزراعة"
)

$readmeFile = Join-Path $staging "اقرأني_تعليمات_النقل_والتشغيل.md"
[System.IO.File]::WriteAllLines($readmeFile, $lines, [System.Text.Encoding]::UTF8)

# Output zip paths: both in Downloads and in Workspace
$zipDestDownloads = "C:\Users\Mohamed Elwan\Downloads\مشروع_حوكمة_دمج_السجلات_التجارية_كاملا.zip"
$zipDestWorkspace = Join-Path $workspace "مشروع_حوكمة_دمج_السجلات_التجارية_كاملا.zip"

if (Test-Path $zipDestDownloads) { Remove-Item $zipDestDownloads -Force }
if (Test-Path $zipDestWorkspace) { Remove-Item $zipDestWorkspace -Force }

Compress-Archive -Path "$staging\*" -DestinationPath $zipDestDownloads -CompressionLevel Optimal
Copy-Item -Path $zipDestDownloads -Destination $zipDestWorkspace -Force

Get-Item $zipDestDownloads | Select-Object FullName, Length, LastWriteTime
